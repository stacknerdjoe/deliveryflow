package com.deliveryflow.notificationservice.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    @Bean
    public TopicExchange deliveryflowExchange() {
        return new TopicExchange("deliveryflow.exchange");
    }

    @Bean
    public Queue orderCreatedQueue() {
        return new Queue("order.created", true);
    }

    @Bean
    public Queue orderAssignedQueue() {
        return new Queue("order.assigned", true);
    }

    @Bean
    public Binding orderCreatedBinding() {
        return BindingBuilder.bind(orderCreatedQueue()).to(deliveryflowExchange()).with("order.created");
    }

    @Bean
    public Binding orderAssignedBinding() {
        return BindingBuilder.bind(orderAssignedQueue()).to(deliveryflowExchange()).with("order.assigned");
    }
}
